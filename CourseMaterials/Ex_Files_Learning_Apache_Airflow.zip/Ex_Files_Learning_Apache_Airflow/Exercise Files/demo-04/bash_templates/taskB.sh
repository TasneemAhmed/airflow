echo TASK B has started!
sleep 4
exit 99
echo TASK B has ended!