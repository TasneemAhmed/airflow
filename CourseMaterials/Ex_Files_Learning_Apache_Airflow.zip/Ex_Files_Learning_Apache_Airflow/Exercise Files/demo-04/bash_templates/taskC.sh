echo TASK C has started!
sleep 10
exit 130
echo TASK C has ended!