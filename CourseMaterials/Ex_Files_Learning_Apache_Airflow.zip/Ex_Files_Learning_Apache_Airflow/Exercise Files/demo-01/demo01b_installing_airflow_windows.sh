# Please install Airflow on Windows using this link
https://www.freecodecamp.org/news/install-apache-airflow-on-windows-without-docker/

# Troubleshooting link if needed
https://airflow.apache.org/docs/apache-airflow/stable/installation/installing-from-pypi.html#airflow-command-is-not-recognized

# After installing run this command

$ airflow version



