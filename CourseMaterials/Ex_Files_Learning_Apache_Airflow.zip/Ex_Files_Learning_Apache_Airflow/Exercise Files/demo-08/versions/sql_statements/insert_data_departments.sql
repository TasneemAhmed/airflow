INSERT INTO {{params.departments_table}} (name) VALUES 
        ('Sales'),
        ('Operations')
