INSERT INTO {{params.employees_table}} (name, title, department_id) VALUES 
        ('John Doe', 'Analyst', 1),
        ('Peter Smith', 'Manager', 2),
        ('Emily Johnson', 'Software Engineer', 1),
        ('Katrina Wilson', 'Scientist', 2)
