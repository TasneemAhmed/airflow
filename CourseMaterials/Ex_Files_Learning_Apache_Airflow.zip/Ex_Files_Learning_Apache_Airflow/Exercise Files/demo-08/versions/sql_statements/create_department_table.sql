CREATE TABLE IF NOT EXISTS {{params.departments_table}} (
            id INTEGER PRIMARY KEY,
            name VARCHAR(50) NOT NULL
        )