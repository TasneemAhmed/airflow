SELECT * FROM {{params.employees_departments_table}}
